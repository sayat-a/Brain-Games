### Hexlet tests and linter status:
[![Actions Status](https://github.com/sayat-a/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/sayat-a/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ea3fe633e82fcc866f94/maintainability)](https://codeclimate.com/github/sayat-a/python-project-49/maintainability)
